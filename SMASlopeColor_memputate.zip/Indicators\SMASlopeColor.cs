#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators
{
	public class SMASlopeColor : Indicator
	{
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"SMA Slope Color by @memputate on X.  Colors based on IsRising or IsFalling";
				Name										= "SMASlopeColor";
				Calculate									= Calculate.OnPriceChange;
				IsOverlay									= true;
				DisplayInDataBox							= true;
				DrawOnPricePanel							= true;
				DrawHorizontalGridLines						= true;
				DrawVerticalGridLines						= true;
				PaintPriceMarkers							= true;
				ScaleJustification							= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				IsAutoScale = false;
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				//See Help Guide for additional information.
				IsSuspendedWhileInactive					= true;
				Period										= 60;
				UpColor										= Brushes.LimeGreen;
				DnColor										= Brushes.Red;
				HideMA									= true;
				ColorBars									= true;
				AddPlot(Brushes.Transparent, "SMA_Slope_Color");
			}

		}

		protected override void OnBarUpdate()
		{
			//Value[0] = (CurrentBar == 0 ? Input[0] : Input[0] * (2.0 / (1 + Period)) + (1 - (2.0 / (1 + Period))) * Value[1]);
			Value[0] = SMA(Close, Period)[0];
			
			if(IsRising(Value))
			{
				if(HideMA)
				PlotBrushes[0][0] = UpColor;
				if(ColorBars)
				BarBrush = UpColor;
			}
			
			
			if(IsFalling(Value))
			{
				if(HideMA)
				PlotBrushes[0][0] = DnColor;
				if(ColorBars)
				BarBrush = DnColor;
			}	
			
			
		}

		#region Properties
		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name="Period", Description="Number of bars to include in the calculation", Order=1, GroupName="Parameters")]
		public int Period
		{ get; set; }

		[NinjaScriptProperty]
		[XmlIgnore]
		[Display(Name="Up Color", Description="Color for rising condition", Order=4, GroupName="Parameters")]
		public Brush UpColor
		{ get; set; }

		[Browsable(false)]
		public string UpColorSerializable
		{
			get { return Serialize.BrushToString(UpColor); }
			set { UpColor = Serialize.StringToBrush(value); }
		}			

		[NinjaScriptProperty]
		[XmlIgnore]
		[Display(Name="Down Color", Description="Color for falling condition", Order=5, GroupName="Parameters")]
		public Brush DnColor
		{ get; set; }

		[Browsable(false)]
		public string DnColorSerializable
		{
			get { return Serialize.BrushToString(DnColor); }
			set { DnColor = Serialize.StringToBrush(value); }
		}			

		[NinjaScriptProperty]
		[Display(Name="Show MA?", Description="Color the plot?", Order=2, GroupName="Parameters")]
		public bool HideMA
		{ get; set; }
		
		[NinjaScriptProperty]
		[Display(Name="Enable BarBrush?", Description="Color the bars?", Order=3, GroupName="Parameters")]
		public bool ColorBars
		{ get; set; }

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> EMA_Slope_Color
		{
			get { return Values[0]; }
		}
		#endregion

	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private SMASlopeColor[] cacheSMASlopeColor;
		public SMASlopeColor SMASlopeColor(int period, Brush upColor, Brush dnColor, bool hideMA, bool colorBars)
		{
			return SMASlopeColor(Input, period, upColor, dnColor, hideMA, colorBars);
		}

		public SMASlopeColor SMASlopeColor(ISeries<double> input, int period, Brush upColor, Brush dnColor, bool hideMA, bool colorBars)
		{
			if (cacheSMASlopeColor != null)
				for (int idx = 0; idx < cacheSMASlopeColor.Length; idx++)
					if (cacheSMASlopeColor[idx] != null && cacheSMASlopeColor[idx].Period == period && cacheSMASlopeColor[idx].UpColor == upColor && cacheSMASlopeColor[idx].DnColor == dnColor && cacheSMASlopeColor[idx].HideMA == hideMA && cacheSMASlopeColor[idx].ColorBars == colorBars && cacheSMASlopeColor[idx].EqualsInput(input))
						return cacheSMASlopeColor[idx];
			return CacheIndicator<SMASlopeColor>(new SMASlopeColor(){ Period = period, UpColor = upColor, DnColor = dnColor, HideMA = hideMA, ColorBars = colorBars }, input, ref cacheSMASlopeColor);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.SMASlopeColor SMASlopeColor(int period, Brush upColor, Brush dnColor, bool hideMA, bool colorBars)
		{
			return indicator.SMASlopeColor(Input, period, upColor, dnColor, hideMA, colorBars);
		}

		public Indicators.SMASlopeColor SMASlopeColor(ISeries<double> input , int period, Brush upColor, Brush dnColor, bool hideMA, bool colorBars)
		{
			return indicator.SMASlopeColor(input, period, upColor, dnColor, hideMA, colorBars);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.SMASlopeColor SMASlopeColor(int period, Brush upColor, Brush dnColor, bool hideMA, bool colorBars)
		{
			return indicator.SMASlopeColor(Input, period, upColor, dnColor, hideMA, colorBars);
		}

		public Indicators.SMASlopeColor SMASlopeColor(ISeries<double> input , int period, Brush upColor, Brush dnColor, bool hideMA, bool colorBars)
		{
			return indicator.SMASlopeColor(input, period, upColor, dnColor, hideMA, colorBars);
		}
	}
}

#endregion
